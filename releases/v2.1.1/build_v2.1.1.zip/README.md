# Juntos por Todos - Projeto Final\n\nEntrega 1: HTML, CSS e JS com foco em semântica e acessibilidade.

